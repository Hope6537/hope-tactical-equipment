var math = require('./math');
console.log(math.add(1,2,3,4));