/*
package org.hope6537.scala

import org.specs.Specification

/**
 * 使用Specs来进行Scala的单元测试
 */
class SpecsTests {

}

/**
 * 测试用例就是这么写的？
 */
object ArithmeticSpec extends Specification {
  "Arithmetic" should {
    "add two numbers" in {
      1 + 1 mustEqual 2
    }
  }
}*/
